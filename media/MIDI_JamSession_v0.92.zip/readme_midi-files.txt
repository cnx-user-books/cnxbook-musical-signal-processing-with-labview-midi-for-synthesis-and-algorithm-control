About the MIDI files in this distribution:
-----------------------------------------

-- trio.mid

   A very short file containing a handful of notes. Illustrates
   multiple tracks and track labeling.


-- stars&stripes.mid

   "Stars and Strips Forever" by John Phillips Sousa, sequenced by Rhino.
   Public domain MIDI obtained from "Prairie Frontier Music/MIDI Files,"
   http://www.prairiefrontier.com/pfcards/Xtrapgs/patriotic.html.


-- kitenkey.zip (need to unpack the .zip file to use the MIDI files)

   "Kitten on the Keys" by Zez Confrey, sequenced by John E. Roache, who
   grants permission to distribute the .zip file for non-commercial use.
   The .zip file contains two MIDI files, and you may use either one.
   Obtained from "The Woodshed Ragtime MIDI Jukebox,"
   http://deckernet.com/midi/rags/

   Try the pan controls on this piece... set the left-hand (on Channel 2)
   to the far left, and set the right-hand (on Channel 1) to the far right.


